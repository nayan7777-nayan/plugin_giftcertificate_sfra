# plugin_giftcertificate

Using this cartride allow you following:

  Creating gift certificate in SFRA<br />
  Checking gift certificate balance<br />
  Using gift certificate as a payment method at checkout<br />


Content:

Import the content asset kept inside site-import folder in your site manullay which are applicable on gift certificate purchase form and checkout form section 


Few changes in base custom cartride:

1) Minicart total quantity count has changed on fly specific change : Controller : cartridge\controllers\Cart.js
2) In Myaccount section orderhistory list has rendered with consolidated with product and gift certificate items : Models : \cartridge\models\order.js